> Project identity updated from Lyric Island to Popliyric. Historical implementation names and source-project references below are retained where they describe the earlier migration baseline. Marketplace metadata is prepared in the root manifest; listing remains unverified and requires public repository discovery.

# Popliyric: Audit and Migration Record

## Audit scope

This audit read the original project at `D:\spotify-dynamic-island` and the native prototype at `outputs/lyric-island-spicetify`. The original Electron source was inspected in place and left unchanged. The original source remains the visual and behavior reference.

## Current architecture

### Original Electron project

| File | Current responsibility |
| --- | --- |
| `index.js` | Spicetify-side playback/lyrics adapter. It reads `Spicetify.Player`, fetches Spotify Color Lyrics, sends track snapshots to `http://127.0.0.1:32145/track`, and polls a local command queue. It sends snapshots every 500 ms. |
| `main.js` | Creates a transparent Electron `BrowserWindow`, places it at the top center, sets it always on top, exposes the local HTTP bridge, relays state over IPC, and checks hover coordinates every 50 ms. |
| `preload.js` | Exposes a small `contextBridge` API for track updates, island state, and player commands. |
| `overlay.html` | Original island markup and renderer logic: lyric position selection, vertical wipe animation, adaptive artwork color sampling/cache, progress display, and playback UI updates. |
| `style.css` | Original compact top island and expanded layout, including vinyl artwork, typography, lyrics, progress, and controls. |
| `package.json` / `package-lock.json` | Electron app entry point and Electron-only development dependency. No production dependency is needed by the native extension. |
| `manifest.json` | Points to `index.js`, but its `preview: true` value is not the image path required by current Marketplace extension manifests. It also references a README that is absent from the original project root. |

The original root contains no README, CONTRIBUTING guide, CHANGELOG, LICENSE file, or `.gitignore`. `package.json` says `ISC`, but that metadata is not a substitute for an included license text. The installed Electron runtime under `node_modules/electron/dist` occupies about 374 MB. It is not part of the proposed extension package.

### Existing native Spicetify prototype

`lyric-island.js` opens a Document Picture-in-Picture window from a top-bar button and uses Spicetify's Player methods directly. It does not require Electron, a local server, IPC, or npm dependencies. It fetches lyrics through `Spicetify.Platform.RequestBuilder` and Spotify's internal Color Lyrics endpoint. The current prototype has one recurring refresh timer plus player event listeners.

The installed prototype is not feature-complete relative to the original. Its current layout differs from the original approved island; it does not show album/artist metadata in the collapsed state, has no progress bar, and uses a generic unavailable-lyrics message instead of a track-information mode. Its lyrics endpoint is an internal Spotify interface and can change without notice.

## Feature migration map

| Feature | Existing source behavior | Native Spicetify path | Limitation / work item |
| --- | --- | --- | --- |
| Synchronized lyrics | `index.js` fetches Color Lyrics; `overlay.html` selects the active line using Spotify playback milliseconds. | Fetch through `Spicetify.Platform.RequestBuilder`; use `Spicetify.Player.getProgress()` as the current position. | Endpoint/response format is internal and not guaranteed. Check sync type and timestamps; fall back to track information when timing is absent. |
| Vertical Wipe | `overlay.html` uses a top-to-bottom gradient driven by line start/end timestamps and a `requestAnimationFrame` loop. | Reuse the CSS gradient and derive its percentage from the latest Player position plus a short local interpolation while playing. Re-anchor on events and a single low-frequency refresh. | Unsynced or incomplete timestamps cannot produce a truthful wipe; show ordinary lyric text instead. |
| Vinyl rotation | CSS groove disc rotates while the playback button indicates playing; artwork occupies the center. | CSS animation keyed to `Player.isPlaying()`, with the cover art and disc in one rotating element. | A document PiP window can throttle animation in the background; the visual resumes from its paused animation state. |
| Adaptive album color | Canvas sampling groups pixels, darkens the dominant color, caches by artwork URL, and uses a dark fallback. | Keep one sample per new artwork URL; update CSS variables in the PiP document. | Canvas sampling may fail if artwork access is blocked; use the same dark fallback and preserve contrast. |
| Playback controls | Electron renderer → preload IPC → localhost command queue → Spicetify Player. | Call `Spicetify.Player.back()`, `togglePlay()`, and `next()` directly. | Verify methods in the running Spotify build; no bridge or command-poll loop is needed. |
| Collapsed / expanded UI | Original Electron window uses top-center placement and hover detection; the original markup includes artwork, current lyric, track details, lyric context, progress, and controls. | A top-bar user gesture opens Document PiP; a click toggles the compact and expanded layouts. | A Spicetify extension cannot reproduce Electron's screen-coordinate hover watcher or set arbitrary window placement. Document PiP availability, placement, resizing, and native window chrome are browser-controlled. |
| Track-information fallback | Original sends title, artist, and cover but does not implement the requested no-lyrics mode. | When lyrics are absent/unsynced, show cover, title, artist, and album in the same island. Retry only on track change or a bounded refresh condition. | Album metadata fields can vary across Player data shapes; include safe fallbacks. |
| Progress | Original renderer displays a progress fill; it is not wired as a seek control. | Display progress from current Player position and duration. | Keep the existing behavior unless seeking is explicitly added later. |
| Long-session stability | Original extension posts snapshots every 500 ms. Requests can overlap when network/lyrics loading is slow; renderer also logs every update. | One timer only while needed, event-driven track/play state updates, non-overlapping lyric fetch per URI, and position recalculation from Player on every render. | Browser background throttling can delay visual frames; recalculate from Spotify position when the page/window wakes. |

## Platform and Marketplace constraints

- A native extension executes inside Spotify. It can create a browser-managed Document PiP window only when the Spotify runtime exposes that API and a user gesture opens it. It is not equivalent to the Electron-owned desktop window: the extension cannot select an arbitrary screen position or control OS-level window behavior. Browser documentation describes Document PiP as an always-on-top browser-managed window; the app cannot promise identical behavior across Spotify versions.
- Current Marketplace publishing guidance requires a public GitHub repository tagged `spicetify-extensions` and a root `manifest.json` with `name`, `description`, `preview`, `main`, and `readme`. Authors and tags are optional. The current native manifest already has the core fields, but Marketplace discovery cannot be verified until a public repository and topic exist. See [Publishing to Marketplace](https://github.com/spicetify/marketplace/wiki/Publishing-to-Marketplace).
- The original project manifest is not Marketplace-ready (`preview` is boolean and the referenced README is missing). The native project manifest will be kept at the project root with relative paths to the extension, README, and preview.
- Local manual installation uses the Spicetify Extensions directory and `spicetify config extensions <filename.js>` followed by `spicetify apply`; Marketplace installation is only possible after public repository discovery.

## Long-session synchronization assessment

The Electron implementation derives progress from `Spicetify.Player.getProgress()` on each 500 ms update rather than incrementing a stale counter, which is a sound source-of-truth choice. Its risk is overlapping asynchronous `sendTrackData()` calls: a track change awaits lyrics, while later interval/event calls can start more snapshots. The renderer cancels and restarts its wipe animation on each snapshot, interpolating between actual positions. It should therefore self-correct when updates resume, but background timer/animation throttling can make the display look frozen until the next update. There is no request timeout, no visible in-flight guard for track fetches beyond URI checks, and no Spotify visibility wake-up handler in the original adapter.

The native implementation should avoid a background command poller, keep a single timer, reject stale lyric responses by track/request version, use player events for immediate state changes, and re-read Player progress when updating or resuming. A long-session live test is still required before calling this stable.

## Incremental implementation plan

1. Keep `D:\spotify-dynamic-island` unchanged as the reference implementation.
2. Make the native extension's collapsed/expanded UI match the original island proportions and hierarchy: artwork + lyric in the pill; track metadata and full lyric context in the expanded panel; progress and controls at the bottom.
3. Restore vinyl grooves, dark adaptive color, typography, and top-to-bottom lyric wipe from the original source.
4. Fix lyric wrapping without single-line ellipsis and add the track-information fallback for missing/unsynchronized lyrics.
5. Keep Spotify Player position authoritative; remove redundant work and guard lyric requests against track changes and duplicate timers.
6. Verify current Spicetify API and Marketplace manifest requirements against official sources; avoid adding dependencies.
7. Add English project documentation, contribution notes, changelog, ignore rules, and an accurate Marketplace preview. Do not create a LICENSE until the owner chooses one.
8. Run static checks and test the extension in Spotify. Record separately which behaviors were verified live and which remain runtime-dependent.
9. Report Marketplace status as “manifest/repository prepared” until a public GitHub repo with the required topic is actually available and discovered.

## Audit decision

The native path is feasible for the core in-Spotify island, lyrics, controls, artwork, adaptive color, and animation. It cannot guarantee Electron-equivalent desktop positioning/hover behavior, and lyric availability remains dependent on Spotify's internal endpoint. Implementation can proceed incrementally inside the separate native project without removing or overwriting any Electron source.

## Implementation and verification status

- Rebuilt the native extension around the original layout: an artwork-and-lyric pill, an expanded vertical panel, track metadata, scrollable lyrics, progress, and playback controls.
- Added unsynchronized-lyric display without a wipe, Track Information Mode when lyrics are missing, bounded artwork-color caching, track/request-version guards, a timeout for lyric requests, a single 500 ms refresh timer while PiP is open, and Player-position re-anchoring.
- Added English README, contribution guide, changelog, `.gitignore`, Marketplace manifest, and an illustrative SVG preview. The user selected MIT; the new extension project has an MIT `LICENSE`.
- Left all files under `D:\spotify-dynamic-island` unchanged. The original Electron app remains available as the reference.
- `node --check` passed for the native extension. Manifest JSON parsed successfully, and its `main`, `preview`, and `readme` paths exist. Static checks found no Electron, localhost-server, or Indonesian UI strings in the extension project.
- The extension was copied to the configured Spicetify Extensions folder and `spicetify apply` completed successfully. Spotify accessibility state exposed a **Lyric Island** top-bar button and current playback metadata.
- A live visual PiP test could not be completed through the desktop automation surface: Spotify did not provide click geometry for the top-bar button and screenshot capture timed out. No claim is made that expanded layout, lyric response, wipe, color sampling, controls, or long-session behavior have passed live testing.
- Marketplace manifest fields and repository topic requirements were verified against current official Marketplace guidance. The project is not publicly listed; this requires a public GitHub repository with the `spicetify-extensions` topic.
